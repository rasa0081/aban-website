import Script from 'next/script';
import ThemeRegistry from '../components/ThemeRegistry';
import ClientLayout from '../components/ClientLayout';
import '../../public/fonts/fontface.css';
import './globals.css';

export const metadata = {
  metadataBase: new URL('https://aban.agency'),
  title: {
    default: 'آژانس تجارت الکترونیک و دیجیتال‌مارکتینگ آبان',
    template: '%s — آژانس آبان',
  },
    description: 'آبان همراه مطمئن کسب‌وکارها در دنیای دیجیتال؛ ارائه خدمات طراحی سایت، سئو، طراحی گرافیک، برندینگ، تولید محتوا، برنامه‌نویسی و دیجیتال مارکتینگ با رویکردی داده محور.',
  keywords: ['گرافیک', 'طراحی سایت', 'تجارت الکترونیک', 'سئو', 'دیجیتال مارکتینگ', 'طراحی وبسایت', 'آبان', 'تهران', 'تبلیغات', 'چاپ تجاری', 'وب سایت', 'وب اپلیکیشن', 'پنل مدیریتی', 'اپلیکیشن موبایل', 'UI UX design', 'تبلیغات محیطی','هویت بصری', 'طراحی بنر','اقلام سازمانی', 'طراحی لوگو', 'انیمیشن', 'بیلبورد', 'موشنگرافی', 'موشن گرافیک', 'موشن دیزاین', 'لوگو موشن', 'رابط کاریری', 'چاپ', 'بازاریابی دیجیتال', 'بازاریابی', 'مارکتینگ', 'تحلیل رقبا', 'برندینگ', 'استراتژی برند', 'کمپین فروش', 'آنالیز بازار', 'تولید محتوا', 'تبلیغ نویسی', 'تقویم محتوایی', 'سناریو نویسی'],
  authors: [{ name: 'آژانس آبان', url: 'https://aban.agency' }],
  creator: 'آژانس آبان',
  publisher: 'آژانس آبان',
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'KMU56htW8iE2lTt2Eyaz4QFAp7QXI_vX5GJlBccc88E',
  },
  openGraph: {
    type: 'website',
    locale: 'fa_IR',
    url: 'https://aban.agency',
    siteName: 'آژانس تجارت الکترونیک و دیجیتال‌مارکتینگ آبان',
    title: 'آژانس آبان — داستان، چهره، اثر',
    description: 'آبان همراه مطمئن کسب‌وکارها در دنیای دیجیتال؛ ارائه خدمات طراحی سایت، سئو، طراحی گرافیک، برندینگ، تولید محتوا، برنامه‌نویسی و دیجیتال مارکتینگ با رویکردی داده محور.',
    images: [
      {
        url: '/Logo.png',
        width: 1200,
        height: 630,
        alt: 'آژانس آبان',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'آژانس آبان — داستان، چهره، اثر',
    description: 'آژانس تجارت الکترونیک آبان — طراحی وبسایت، توسعه اپلیکیشن، سئو و بازاریابی دیجیتال در تهران.',
    images: ['/Logo.png'],
  },
  alternates: {
    canonical: 'https://aban.agency',
  },
  icons: {
    icon: '/favicon.ico',
    apple: '/favicon.ico',
  },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/gh/rastikerdar/vazir-font@v30.1.0/dist/font-face.css"
        />
        {/* JSON-LD: Organization structured data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'Organization',
              name: 'آژانس آبان',
              alternateName: 'Aban Agency',
              url: 'https://aban.agency',
              logo: 'https://aban.agency/Logo.png',
              description: 'آژانس تجارت الکترونیک آبان — طراحی وبسایت، توسعه اپلیکیشن، سئو و بازاریابی دیجیتال',
              slogan: 'داستان، چهره، اثر',
              address: {
                '@type': 'PostalAddress',
                addressLocality: 'تهران',
                addressCountry: 'IR',
              },
              contactPoint: {
                '@type': 'ContactPoint',
                contactType: 'customer service',
                availableLanguage: 'Persian',
              },
              sameAs: [
                // 'https://instagram.com/aban.agency',
                // 'https://linkedin.com/company/aban-agency',
              ],
            }),
          }}
        />
      </head>
      <body>
        <ThemeRegistry>
          <ClientLayout>
            {children}
          </ClientLayout>
        </ThemeRegistry>
        <Script
          src="https://www.googletagmanager.com/gtag/js?id=G-0RMK1S417Y"
          strategy="afterInteractive"
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-0RMK1S417Y');
          `}
        </Script>
      </body>
    </html>
  );
}